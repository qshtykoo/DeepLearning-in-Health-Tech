from .main import sequential_model_to_ascii_printout

# also a shorter name
keras2ascii = sequential_model_to_ascii_printout
